@echo off
rem === Doi ten file nay thanh config.bat roi dien thong tin cua ban ===
rem === (hoac chay cai-dat.bat de no tu tao giup ban) ===

rem Unified key lay o trang Keys trong dashboard FreeLLMAPI
set "FREELLM_KEY=freellmapi-DAN_KEY_CUA_BAN_VAO_DAY"

rem Dia chi server. App Desktop mac dinh la cong 31415
set "FREELLM_URL=http://127.0.0.1:31415"

rem Thu muc du an ma Claude Code se mo
set "PROJECT_DIR=%USERPROFILE%\my-project"

rem Neu file mo-freellmapi.bat khong tu tim thay app, bo chu rem va sua duong dan:
rem set "APP_EXE=C:\Users\TEN_BAN\AppData\Local\Programs\FreeLLMAPI\FreeLLMAPI.exe"

rem Neu gap loi "API error" khi chat, thu bo chu rem dong duoi:
rem set "CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS=1"
