@echo off
title Cai dat Claude Code + FreeLLMAPI
cd /d "%~dp0"

echo ==========================================
echo   Cai dat Claude Code + FreeLLMAPI
echo ==========================================
echo.
echo Lay unified key o dashboard FreeLLMAPI, trang Keys.
echo Dan key bang chuot phai hoac Ctrl+Shift+V roi nhan Enter.
echo.
set "KEY="
set /p KEY=Unified key (bat dau bang freellmapi-): 

echo %KEY% | findstr /b /i "freellmapi-" >nul
if errorlevel 1 goto badkey

set "DEF_URL=http://127.0.0.1:31415"
set "URL="
set /p URL=Dia chi server [Enter = %DEF_URL%]: 
if not defined URL set "URL=%DEF_URL%"

set "DEF_DIR=%USERPROFILE%\my-project"
set "DIR="
set /p DIR=Thu muc du an [Enter = %DEF_DIR%]: 
if not defined DIR set "DIR=%DEF_DIR%"

> config.bat echo @echo off
>> config.bat echo set "FREELLM_KEY=%KEY%"
>> config.bat echo set "FREELLM_URL=%URL%"
>> config.bat echo set "PROJECT_DIR=%DIR%"

echo.
echo Da tao config.bat. File nay chua key cua ban, dung dua len GitHub.
echo Bay gio hay double-click claude-free.bat de bat dau.
echo.
pause
exit /b 0

:badkey
echo.
echo Key khong hop le. Key phai bat dau bang freellmapi-
echo Neu khong dan duoc, doi ten config.example.bat thanh config.bat
echo roi mo bang Notepad va dien key vao.
echo.
pause
exit /b 1
