@echo off
title Mo FreeLLMAPI

rem Dung /quiet de chi bat server, khong mo trinh duyet
set "QUIET=0"
if /i "%~1"=="/quiet" set "QUIET=1"

set "URL=http://127.0.0.1:31415"
if exist "%~dp0config.bat" call "%~dp0config.bat"
if defined FREELLM_URL set "URL=%FREELLM_URL%"
for /f "tokens=3 delims=:/" %%P in ("%URL%") do set "PORT=%%P"
set /a TRIES=0

netstat -ano | findstr /r ":%PORT% .*LISTENING" >nul
if not errorlevel 1 goto ready

echo Server chua chay, dang tim app FreeLLMAPI...

rem --- Tim file .exe ---
if not defined APP_EXE for /f "delims=" %%F in ('where /r "%LOCALAPPDATA%\Programs" *freellmapi*.exe 2^>nul ^| findstr /v /i "uninstall"') do if not defined APP_EXE set "APP_EXE=%%F"
if not defined APP_EXE for /f "delims=" %%F in ('where /r "%ProgramFiles%\FreeLLMAPI" *freellmapi*.exe 2^>nul ^| findstr /v /i "uninstall"') do if not defined APP_EXE set "APP_EXE=%%F"

rem --- Neu khong co .exe, tim shortcut trong Start Menu ---
if not defined APP_EXE for /f "delims=" %%F in ('dir /s /b "%APPDATA%\Microsoft\Windows\Start Menu\Programs\*freellmapi*.lnk" "%ProgramData%\Microsoft\Windows\Start Menu\Programs\*freellmapi*.lnk" 2^>nul ^| findstr /v /i "uninstall"') do if not defined APP_LNK set "APP_LNK=%%F"

if defined APP_EXE goto launch_exe
if defined APP_LNK goto launch_lnk
goto notfound

:launch_exe
echo Dang mo: "%APP_EXE%"
start "" "%APP_EXE%"
goto wait

:launch_lnk
echo Dang mo: "%APP_LNK%"
start "" "%APP_LNK%"

:wait
timeout /t 3 /nobreak >nul
set /a TRIES+=1
netstat -ano | findstr /r ":%PORT% .*LISTENING" >nul
if not errorlevel 1 goto ready
if %TRIES% GEQ 25 goto fail
goto wait

:ready
echo Server dang chay o %URL%
if "%QUIET%"=="1" exit /b 0
start "" "%URL%"
echo.
echo Server chay nen trong app FreeLLMAPI, o khay he thong goc phai taskbar.
echo Dong cua so nay khong lam tat server.
echo.
pause
exit /b 0

:notfound
echo Khong tim thay app FreeLLMAPI tren may.
echo Hay mo app FreeLLMAPI tu Start Menu mot lan, sau do chay lai file nay.
echo Hoac dien APP_EXE trong config.bat.
pause
exit /b 1

:fail
echo Khong thay server sau 75 giay. Hay mo app FreeLLMAPI thu cong.
pause
exit /b 1
