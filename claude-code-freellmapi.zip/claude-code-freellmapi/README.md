# Claude Code + FreeLLMAPI (Windows)

Chạy [Claude Code](https://docs.claude.com/en/docs/claude-code) thông qua [FreeLLMAPI](https://github.com/tashfeenahmed/freellmapi), một server chạy trên máy bạn, gom các gói miễn phí của nhiều nhà cung cấp (Groq, Google, NVIDIA, OpenRouter...) về một địa chỉ duy nhất.

Bộ file `.bat` này giúp bạn bật server và mở Claude Code chỉ bằng một lần double-click.

> Dự án không chính thức, không liên kết với Anthropic hay FreeLLMAPI.

## Cách hoạt động

```
Claude Code  -->  FreeLLMAPI Desktop (127.0.0.1:31415)  -->  Groq / Google / NVIDIA / ...
```

| Thành phần | Chi tiết |
|---|---|
| Server | App **FreeLLMAPI Desktop**, mặc định cổng `31415` (chạy ở khay hệ thống) |
| Unified key | Lấy ở trang **Keys** trong dashboard, bắt đầu bằng `freellmapi-` |
| Provider key | Key của Groq, Google... Phải thêm vào dashboard, nếu không sẽ báo `no_providers_configured` |

Nếu bạn chạy FreeLLMAPI bằng `npm run dev` hoặc Docker thì cổng thường là `3001`. Khi đó đổi `FREELLM_URL` trong `config.bat` thành `http://127.0.0.1:3001` (file `mo-freellmapi.bat` chỉ tự bật được bản Desktop).

## Yêu cầu

- Windows
- Claude Code đã cài (gõ `claude` trong cmd chạy được)
- App FreeLLMAPI Desktop đã cài
- Ít nhất một provider key (ví dụ Groq) đã thêm vào dashboard

## Cài đặt (làm một lần)

1. Tải repo về (nút **Code → Download ZIP**) và giải nén.
2. Mở app FreeLLMAPI, vào trang **Keys**, copy **Unified key** và thêm provider key.
3. Double-click `cai-dat.bat`, dán unified key, nhấn Enter. File sẽ tạo `config.bat` cho bạn.
   - Nếu không dán được: đổi tên `config.example.bat` thành `config.bat`, mở bằng Notepad và điền key.
4. Double-click `claude-free.bat`. Gõ `xin chao` để thử.

> Windows có thể hiện cảnh báo SmartScreen khi mở file `.bat` tải về. Chọn **More info → Run anyway**.

## Các file

| File | Việc nó làm |
|---|---|
| `cai-dat.bat` | Hỏi key, tạo `config.bat` |
| `claude-free.bat` | Bật server nếu chưa chạy, rồi mở Claude Code đã trỏ vào FreeLLMAPI |
| `mo-freellmapi.bat` | Bật server nếu chưa chạy, rồi mở dashboard trên trình duyệt |
| `config.example.bat` | Mẫu cấu hình |
| `config.bat` | Cấu hình của bạn (chứa key, **không** đưa lên GitHub) |

Server chạy nền trong app FreeLLMAPI ở khay hệ thống. Đóng cửa sổ cmd không làm tắt server. Muốn tắt, chuột phải vào biểu tượng app ở khay và chọn Quit.

## Lỗi thường gặp

| Triệu chứng | Nguyên nhân | Cách sửa |
|---|---|---|
| `Key entry cancelled` khi chạy `npx freellmapi setup-claude` | cmd không nhận thao tác dán ở bước nhập key | Dùng `cai-dat.bat` thay cho lệnh `npx` |
| Cảnh báo `EBADENGINE` khi chạy `npx freellmapi` | Gói yêu cầu Node `>=20.18 <25`, máy bạn dùng bản mới hơn | Chỉ là cảnh báo. Nếu gặp lỗi lạ, cài Node 22 LTS |
| `API error · Retrying...` khi chat | Chưa có provider key, hoặc Claude Code gửi tính năng thử nghiệm mà server không hiểu | Thêm provider key trong dashboard. Bỏ chữ `rem` ở dòng `CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS` trong `config.bat` |
| `401 Invalid API key` | Unified key không khớp app đang chạy | Copy lại key ở trang **Keys**, chạy lại `cai-dat.bat` |
| `no_providers_configured` | Chưa thêm provider key | Thêm key Groq... ở trang **Keys** |
| `Not logged in · Please run /login` | Claude Code không đọc được cấu hình | Mở bằng `claude-free.bat`, đừng chạy `/login` |
| Dòng đầu vẫn hiện `Opus 5.5` | Bình thường, FreeLLMAPI tự chuyển sang model miễn phí | Gõ `/model` nếu muốn chọn model khác |
| `Khong tim thay app FreeLLMAPI` | App cài ở vị trí khác | Mở app một lần từ Start Menu, hoặc điền `APP_EXE` trong `config.bat` |

Kiểm tra server bằng curl (tuỳ chọn):

```
curl http://127.0.0.1:31415/v1/messages -H "x-api-key: UNIFIED_KEY" -H "anthropic-version: 2023-06-01" -H "content-type: application/json" -d "{\"model\":\"claude-sonnet-4-5\",\"max_tokens\":50,\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}"
```

Giữ nguyên chữ `x-api-key:`, key chỉ nằm sau dấu hai chấm.

## Bảo mật

- **Không bao giờ** đưa `config.bat` hoặc unified key lên GitHub. `.gitignore` đã bỏ qua `config.bat`.
- Nếu lỡ lộ key, tạo lại key trong dashboard rồi chạy lại `cai-dat.bat`.
- Các gói miễn phí có giới hạn tốc độ. Model nào báo hết hạn mức thì chọn model khác hoặc thêm provider key khác.
