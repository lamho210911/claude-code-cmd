@echo off
title Claude Code - FreeLLMAPI

if not exist "%~dp0config.bat" goto noconfig
call "%~dp0config.bat"

echo %FREELLM_KEY% | findstr /i "DAN_KEY" >nul
if not errorlevel 1 goto noconfig

if not defined FREELLM_URL set "FREELLM_URL=http://127.0.0.1:31415"
if not defined PROJECT_DIR set "PROJECT_DIR=%USERPROFILE%\my-project"

where claude >nul 2>&1
if errorlevel 1 goto noclaude

rem === Bat server FreeLLMAPI neu chua chay ===
call "%~dp0mo-freellmapi.bat" /quiet
if errorlevel 1 exit /b 1
title Claude Code - FreeLLMAPI

rem === Cau hinh Claude Code tro vao FreeLLMAPI ===
set "ANTHROPIC_BASE_URL=%FREELLM_URL%"
set "ANTHROPIC_AUTH_TOKEN=%FREELLM_KEY%"

if not exist "%PROJECT_DIR%" mkdir "%PROJECT_DIR%"
cd /d "%PROJECT_DIR%"
claude
exit /b 0

:noconfig
echo Chua co config.bat hoac chua dien key.
echo Hay chay cai-dat.bat truoc.
pause
exit /b 1

:noclaude
echo Khong tim thay lenh claude. Hay cai Claude Code truoc.
pause
exit /b 1
